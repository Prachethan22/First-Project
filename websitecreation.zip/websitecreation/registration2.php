



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page2</title>
    <link rel="stylesheet" href="stylereg.css">
</head>
<body >
    <div class="headdiv">
        <header>
            <ul class="headerform">
                <li><a class="navbar" href="mainpage.html" target="_blank">  Main Page  </a></li>
                <li><a class="navbar" href="loginpage.php" target="_blank">  Login Page  </a></li>
            </ul>

        </header><br><br>
    </div>
    <div id="formdiv">
        <form action="registration2.php" method="post" align="center" >
            <ul class="formlist"><!--THESE ARE LABELLED AS "FIELDS" IN A SEPARATE CLASS-->
                <li><label for="username" class="label">Enter Username here: </label><br>
                    <input type="text" class="fields" name="username"><br></li><br>
    
                <li><label for="mail" class="label">Enter the mail ID: </label><br>
                    <input type="email" class="fields" name="mail"><br></li><br>
    
                <li><label for="pwd" class="label">Enter your desired password:</label><br>
                    <input type="password" class="fields" name="pwd"><br></li><br>
    
                <li><label for="repwd" class="label">Confirm your password: </label><br>
                    <input type="password" class="fields" name="repwd"><br></li><br>
    
                <li><input type="submit" class="submit" name="submit" value="click here to submit!">
                    <input type="reset" class="reset" name="reset" value="clear all"></li>\



                
    
    
            
        </form>
    </div>
    <div class="kitten">
        <img src="kitten.png">
    </div>

    <?php
    if(isset($_REQUEST['submit'])){
        $username = $_REQUEST['username'];
        $mail = $_REQUEST['mail'];
        $password = $_REQUEST['pwd'];
        $repassword = $_REQUEST['repwd'];
    

    
        $con = mysqli_connect("localhost","root","","reglog");
    

    
        $result = "insert into logincreds values('$username','$mail','$password','$repassword')";
    

    
        $sql = mysqli_query($con, $result);
    
        if($sql){
            echo "<script>alert('You have registered successfully!')</script>";
        }

    }
 
    

    
    ?>

</body>
</html>

