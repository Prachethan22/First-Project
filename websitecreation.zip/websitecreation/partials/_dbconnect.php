<?php
$server="localhost";
$username ="root";
$password="";
$database="reglog";

$conn=mysqli_connect($server, $username, $password, $database);

if($conn){
    echo "<script>alert('connection successful')</script>";
}
else{
    die("error". mysqli_connect_error());
}

?>