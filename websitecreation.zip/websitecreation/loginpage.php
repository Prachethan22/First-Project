<?php
    if(isset($_REQUEST['submit'])){

        $username = $_REQUEST['uname'];
        
        $password = $_REQUEST['pwd'];
    
    
        
    
        $con = mysqli_connect("localhost","root","","reglog");
    
        
    
        $result = "select * from logincreds where username='$username' and pwd='$password'";
    
        
    
        $sql = mysqli_query($con,$result);
    
        if($d = mysqli_fetch_assoc($sql)){
            echo "<script>alert('you have logged in successfully');
            window.location.href='gallery.html'</script>";
        }
        else{
            echo "<script>alert('Username or Password Incorrect')</script>";
        }

    }
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
    <link rel="stylesheet" href="stylelogin.css">
    

    

</head>
    

<body>
    <header>
        <div>
            <a href="registration2.php">sign up!</a> 
            <a href="mainpage.html" >MainPage</a>
        </div>


    </header><br>

    <div>
        <form align="center" action="loginpage.php" method="post">
            <ul>
                <li><label for="uname">Enter username</label><br>
                    <input type="text" name="uname" placeholder="enter your username" ></li><br><br>
    
    
                <li><label for="pwd">Enter your password</label><br>
                    <input type="password" name="pwd" placeholder="enter password"></li><br>
    
    
                <li ><input type="submit" class="tap" name="submit" value="continue">
                    <input type="reset" class="tap" name="reset" value="clear all"><li>
            </ul>
        </form>
    </div>   
    

</body>

</html>